# New GWAS pipeline in C/C++

## TODO

- [x] Add bgen reader with 2-bit coding
- [x] Add R2 (2-bit and double)
- [x] add option parser
- [x] add sample parser
- [x] prepare data for kernel
- [x] Add pipeline kernel
- [x] multi-thread
- [ ] memory pool
- [ ] other optimizations
	

