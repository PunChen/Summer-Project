#ifndef  __NEWGWAS_H__
#define  __NEWGWAS_H__

#include <vector>
#include "variants.h"

#define REAL double

bool process_snps(std::vector<NewGwas::Variant> & variants, REAL** Xs, REAL* Y, int start, int chunk, int nums, int X_size, std::string Y_type, std::vector<double> & res);
bool out_res(std::string &ofilename,std::vector<NewGwas::Variant> &variants,std::vector<double> &res);
bool parallel_process_snps(std::vector<NewGwas::Variant> & variants, REAL** Xs, REAL* Y, int start, int chunk, int nums, int X_size, std::string Y_type, std::vector<double> & res);
bool prepare_data(int ids, std::vector<NewGwas::Variant> & variants, REAL* buffer, int start, int nums);
bool do_calculation(double* X, double* Y, int N, int M, std::string Y_type, int iters, std::vector<double> & res);
#endif //__NEWGWAS_H__
