#ifndef __VARIANTS_H__
#define __VARIANTS_H__

#include <string>
#include <vector>
#include <stdint.h>
#include <iostream>

namespace NewGwas {

    struct Variant {
        std::string chromosome;
        uint32_t position;
        std::string rsid;
        std::vector <std::string> alleles;
        //std::vector<std::vector<double> > probs ;
        //std::vector<double> snps;
        uint8_t *snps; //2-bit encode

    };

    void probsToSnps(std::vector <std::vector<double>> &probs, uint8_t *&snps, bool print) {
        //snps = new uint8_t[(probs.size() - 1) / 4 + 1];
        int length = (probs.size() - 1) / 4 + 1;
        snps = (uint8_t *) malloc(length * sizeof(uint8_t));

        for (int i = 0; i < length; i++) snps[i] = 0x00;

        uint8_t snp;
        for (int i = 0; i < probs.size(); i++) {
            snp = 0x00;
            if (probs[i].size() <= 1) snp = 0x00;
            else {
                for (int j = 0; j < probs[i].size() - 1; j++) {
                    if (probs[i][j] < probs[i][j + 1]) snp = (uint8_t)(j);
                }
            }

            //int id = i >> 2;
            //int tail = i & 0x03;
            if (print && ((int) snp)) std::cout << (int) snp << std::endl;
            snps[i >> 2] = snps[i >> 2] | (snp << ((i & 0x03) << 1));
        }

        return;
    }

    void snpsToDouble(uint8_t *&snps, double *&snps_double, int number_of_samples) {
//        std::cerr << "snps_double : " << snps_double << std::endl;
        // memory already allocated
        // snps_double = new double[number_of_samples];
        for (int i = 0; i < number_of_samples; i++) {
            snps_double[i] = (double) ((snps[i >> 2] >> ((i & 0x03) << 1)) & 0x03);
        }
    }



}//namespace NewGwas

#endif //__VARIANTS_H__
