#ifndef __STATS_H__
#define __STATS_H__
/**
 * Some basic stats functions
 */
#include <stdint.h>

namespace NewGwas{

namespace Stats{

/**
 * calc R^2 for two samples
 */
double R2(double * s1, double * s2, int number_of_samples);
double R2(uint8_t * s1, uint8_t * s2, int number_of_samples);

}//Stats

}//NewGwas

#endif //__STATS_H__
