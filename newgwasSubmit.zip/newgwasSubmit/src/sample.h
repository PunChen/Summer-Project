#ifndef __SAMPLE_H__
#define __SAMPLE_H__

#include "csvparser.hpp"
#include <stdint.h>
#include <string>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <cstdlib>

#define REAL double

using namespace csv;

namespace NewGwas {

    class SampleParser {
    public:
        SampleParser(std::string sample_file_name) {
            std::ifstream f(sample_file_name);
            if (!f.is_open()) {
                std::cerr << sample_file_name << " not exist!" << std::endl;
                exit(0);
            }

            CsvParser parser = CsvParser(f).delimiter(' ');
            for (auto &row : parser) {
                std::vector <std::string> r;
                for (auto &field: row) {
                    r.push_back(field);
                }
                csv.push_back(r);
            }

            if (csv.size()) {
                cols = csv[0].size();
                rows = csv.size() - 2;//exclude two headers
            }

            // Move the memory allocate process in the processHeader() function, according header counts allocate
            // ids = (int **)malloc(sizeof(int *) * cols);
            // data = (REAL **)malloc(sizeof(REAL *) * cols);

            return;
        }

        ~SampleParser() {
            for (int i = 0; i < this->id_count; i++)
                free(ids[i]);
            for (int i = 0; i < this->data_count; i++)
                free(data[i]);

            free(ids);
            free(data);
        }

        bool getSampleHeader() {
            name = csv[0];
            type = csv[1];

            print_name();
            print_type();

            processHeader();

            return true;
        }

        bool getSample() {
            name = csv[0];
            type = csv[1];

            //print_name();
            //print_type();

            processHeader();

            //convert string to number
            numConversion();

            return true;
        }

        // Get columns data.
        std::vector <std::vector<double>> getColumns(const std::vector<int> &clms) {

            std::vector <std::vector<double>> res;
            std::vector<double> values;
            if (!clms.empty()) {
                for (auto i : clms) {
                    for (int j = 0; j < rows; ++j) {
                        if (csv[j + 2][i] == "NA")
                            values.emplace_back(0);
                        else
                            values.emplace_back(std::stod(csv[j + 2][i]));
                    }
                    res.push_back(values);
                    values.clear();
                }
            }
            return res;
        }

        // X have other chunks, Y havn't
        // void getColumns( const std::vector<int>& clms, double *data, uint64_t chunk = 0)
        void getColumns(const std::vector<int> &clms, double *data) {
            uint64_t offset, idx;

            if (!clms.empty()) {
                for (int i = 0; i < clms.size(); ++i) {
                    offset = i * rows;
                    idx = clms[i];
                    for (int j = 0; j < rows; ++j) {
                        if (csv[j + 2][idx] == "NA")
                            data[offset + j] = 0;
                        else
                            data[offset + j] = std::stod(csv[j + 2][idx]);
                    }
                }
            }
            return;
        }

        std::ostream &summarise(std::ostream &o) const {
            o << "Summary of covariates and phenotypes\n";

            o << "# discrete variables : " << d_var.size() << '\n';
            for (auto v : d_var)
                o << "  " << name[v] << " : type = D (Discrete covariate)\n";

            o << "# continuous variables : " << c_var.size() << '\n';
            for (auto v : c_var)
                o << "  " << name[v] << " : type = C (Continuous covariate)\n";

            o << "# phenotypes : " << bin_ph.size() + con_ph.size() << '\n';
            for (auto ph : bin_ph)
                o << "  " << name[ph] << " : type = B (Binary phenotype)\n";
            for (auto ph : con_ph)
                o << "  " << name[ph] << " : type = P (Continuous phenotype)\n";

            return o;
        }

    public:
        int id_count = 0;
        int data_count = 0;
        // std::unordered_map<std::string, int* > id_map;
        // std::unordered_map<std::string, REAL* > data_map;
        std::unordered_map<int, int *> id_map;
        std::unordered_map<int, REAL *> data_map;
        uint64_t cols = 0;
        uint64_t rows = 0;
        std::vector <std::string> name;
        std::vector <std::string> type;

        // Records the covariables and phenotypes.
        std::vector<int> d_var;
        std::vector<int> c_var;
        std::vector<int> bin_ph;
        std::vector<int> con_ph;

    private:

        //CsvParser parser(NULL);
        std::vector <std::vector<std::string>> csv;
        int **ids;
        REAL **data;

        void print_name() {
            for (auto &col_name : name)
                std::cerr << col_name << " ";
            std::cerr << std::endl;

            return;
        }

        void print_type() {
            for (auto &col_type : type)
                std::cerr << col_type << " ";
            std::cerr << std::endl;

            return;
        }

        /**
          * 0 (for the first identifier column)
         * D (for a column containing discrete values, e.g. a set of strings)
         * P or C - for columns containing continuous value - each value must be numerical, or a missing value.
         * B - for a column containing a binary trait. The values in this column must be '0', '1', 'control', or 'case'.
         * pheno type is P or B and cov type is C or D。
         */
        void processHeader() {
            this->id_count = 0;
            for (int i = 0; i < type.size(); i++) {
                if (type[i] == "0") this->id_count++;
            }
            this->data_count = this->cols - this->id_count;

            ids = (int **) malloc(sizeof(int *) * id_count);
            data = (REAL **) malloc(sizeof(REAL *) * data_count);

            //malloc data
            for (int i = 0; i < this->id_count; i++)
                ids[i] = (int *) malloc(sizeof(int) * this->rows);
            for (int i = 0; i < this->data_count; i++)
                data[i] = (REAL *) malloc(sizeof(REAL) * this->rows);

            int tmp_id = 0;
            int tmp_data_id = 0;
            for (int i = 0; i < type.size(); i++) {
                char T = type[i][0];

                switch (T) {
                    case '0':
                        // id_map.insert({name[i], ids[tmp_id++]});
                        id_map.insert({i, ids[tmp_id++]});
                        //std::cerr << "col: " << i << " type: int" << std::endl;
                        break;
                    case 'D':
                        // data_map.insert({name[i], data[tmp_data_id++]});
                        data_map.insert({i, data[tmp_data_id++]});
                        d_var.emplace_back(i);
                        //std::cerr << "col: " << i << " type: string" << std::endl;
                        break;
                    case 'P':
                        // data_map.insert({name[i], data[tmp_data_id++]});
                        data_map.insert({i, data[tmp_data_id++]});
                        con_ph.emplace_back(i);
                        //std::cerr << "col: " << i << " type: double" << std::endl;
                        break;
                    case 'C':
                        // data_map.insert({name[i], data[tmp_data_id++]});
                        data_map.insert({i, data[tmp_data_id++]});
                        c_var.emplace_back(i);
                        //std::cerr << "col: " << i << " type: double" << std::endl;
                        break;
                    case 'B':
                        // data_map.insert({name[i], data[tmp_data_id++]});
                        data_map.insert({i, data[tmp_data_id++]});
                        bin_ph.emplace_back(i);
                        //std::cerr << "col: " << i << " type: bool" << std::endl;
                        break;

                    default:
                        std::cerr << "col: " << i << " type: not recognized" << std::endl;
                        break;
                }
            }


            //std::cerr << "0 types: " << id_count << std::endl;


            return;
        }

        void numConversion() {
            //FIXME: deal with type D
            for (int i = 0; i < name.size(); i++) {
                //deal with map (int or double)
                //std::cout << "name: " << name[i] << std::endl;
                //std::cout << "rows: " << rows << std::endl;
                //std::cout << "cols: " << cols << std::endl;
                // if(data_map.count(name[i]))
                if (data_map.count(i)) {
                    // double *pt = data_map[name[i]];
                    double *pt = data_map[i];
                    for (int j = 0; j < rows; j++) {
                        if (csv[j + 2][i] == "NA") {
                            //std::cout << csv[j+2][i] << std::endl;
                            pt[j] = 0.0;
                        } else {
                            //std::cout << csv[j+2][i] << std::endl;
                            pt[j] = std::stod(csv[j + 2][i]);
                        }
                    }
                    // }else if(id_map.count(name[i])){
                } else if (id_map.count(i)) {
                    // int *pt = id_map[name[i]];
                    int *pt = id_map[i];
                    for (int j = 0; j < rows; j++) {
                        if (csv[j + 2][i] == "NA") {
                            //std::cout << csv[j+2][i] << std::endl;
                            pt[j] = 0;
                        } else {
                            //std::cout << csv[j+2][i] << std::endl;
                            pt[j] = std::stoi(csv[j + 2][i]);
                        }
                    }
                } else {
                    std::cerr << "WARNNING: " << name[i] << " not found in map" << std::endl;
                }
            }
        }
    };

}//NewGwas
#endif //__SAMPLE_H__
