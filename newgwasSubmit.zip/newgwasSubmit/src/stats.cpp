#include <stdint.h>
#include <cmath>

namespace NewGwas{

namespace Stats{

double R2(double * s1, double * s2, int number_of_samples){

	double h1 = 0.0;
	double h2 = 0.0;
	double h3 = 0.0;
	double h4 = 0.0;

	for(int i = 0; i < number_of_samples; i++)
	{
		if((int)(s1[i] + s2[i]) ==  0) h1 += 1.0;
		if((int)(s1[i] + s2[i]) ==  4) h4 += 1.0;
		if((int)(s1[i] - s2[i]) ==  2) h2 += 1.0;
		if((int)(s1[i] - s2[i]) == -2) h3 += 1.0;
	}

	h1 = sqrt(h1 / number_of_samples); 
	h2 = sqrt(h2 / number_of_samples);
	h3 = sqrt(h3 / number_of_samples);
	h4 = sqrt(h4 / number_of_samples);
	
	if(h1 == 0 || h2 == 0 || h3 == 0 || h4 == 0)
		return 1.0;
	else
		return (h4-(h3+h4)*(h2+h4))*(h4-(h3+h4)*(h2+h4))/((h3+h4)*(h2+h4)*(h1+h2)*(h1+h3));
}

//TODO:imp it for 2bit version	
double R2(uint8_t * s1, uint8_t * s2, int number_of_samples){
	double h1 = 0.0;
	double h2 = 0.0;
	double h3 = 0.0;
	double h4 = 0.0;

	for(int i = 0; i < number_of_samples; i++)
	{
		double s1_val = (double) ((s1[i >> 2] >> ((i & 0x03) << 1) ) & 0x03);
		double s2_val = (double) ((s2[i >> 2] >> ((i & 0x03) << 1) ) & 0x03);

		if((int)(s1_val + s2_val) ==  0) h1 += 1.0;
		if((int)(s1_val + s2_val) ==  4) h4 += 1.0;
		if((int)(s1_val - s2_val) ==  2) h2 += 1.0;
		if((int)(s1_val - s2_val) == -2) h3 += 1.0;
	}

	h1 = sqrt(h1 / number_of_samples); 
	h2 = sqrt(h2 / number_of_samples);
	h3 = sqrt(h3 / number_of_samples);
	h4 = sqrt(h4 / number_of_samples);
	
	if(h1 == 0 || h2 == 0 || h3 == 0 || h4 == 0)
		return 1.0;
	else
		return (h4-(h3+h4)*(h2+h4))*(h4-(h3+h4)*(h2+h4))/((h3+h4)*(h2+h4)*(h1+h2)*(h1+h3));

}

}//Stats

}//NewGwas
