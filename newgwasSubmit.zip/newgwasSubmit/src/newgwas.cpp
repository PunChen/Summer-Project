#include "newgwas.h"
#include "bgen_reader.h"
#include "variants.h"
#include "cxxopts.hpp"
#include "sample.h"
#include "utils.h"
// #include "kernel/glm.h"
#include <iostream>
#include <chrono>
#include <cstring>
#include <omp.h>
#include <cstdio>
#include <vector>

extern "C" {

#include "kernel/glm.h"

}
int TTT;
using namespace std;

bool saveResult(std::string &ofilename, std::vector<NewGwas::Variant> &variants, std::vector<double> &res) {
    std::ofstream out(ofilename);
    std::vector<string> title = {"rsid", "chromosome", "position", "alleleA", "alleleB", "index"};
    for (int i = 0; i < res.size() / variants.size(); i++)title.emplace_back("coeff" + to_string(i));
    for (auto &str:title)out << str << " ";
    out << endl;
    int index = 0;
    for (auto &it:variants) {
        std::vector<string> data = {it.rsid, it.chromosome, to_string(it.position), it.alleles[0], it.alleles[1],
                                    to_string(++index),};
        for (int i = (index - 1) * variants.size(); i < index * variants.size(); i++)
            data.emplace_back(to_string(res[i]));
        for (auto &str:data)out << str << " ";
        out << endl;
    }
    out.close();
    return true;
}

int main(int argc, char **argv) {
    freopen("/mnt/c/Users/yanli/Desktop/uni_result21_all.out", "r", stdin);

    // start time
    auto time_start = chrono::steady_clock::now();

    string ifilename;
    string ofilename;
    string sample_file;
    string pheno;
    string pca;
    vector <string> pcas;
    string mode_flag = "";

    int chunk = 100;
    int range = 100;
    double p_cut = 1e-5;

    /**
     * Operation parser
     */

    cerr << endl << "Executing scripts:" << endl;
    for (int i = 0; i < argc; ++i) {
        cerr << argv[i] << " ";
    }
    cerr << endl << endl;

    cxxopts::Options options(argv[0], "newgwas in C/C++");
    options.add_options()
            ("m,mode", "select mode [debug[d]]/[verbose[v]]", cxxopts::value<string>())
            ("h,help", "print help infomation")
            ("g,bgen", "input file name [bgen format]", cxxopts::value<string>())
            ("o,output", "output file name", cxxopts::value<string>())
            ("s,sample", "input sample file", cxxopts::value<string>())
            ("p,pheno", "choose pheno [must be defined in sample file]", cxxopts::value<string>())
            ("c,chunk", "chunk size per round [default 100]", cxxopts::value<int>())
            ("r,range", "search range for each SNP [default 100]", cxxopts::value<int>())
            ("threshold", "p-value's significance threshold [default 1e-5]", cxxopts::value<double>())
            ("pca", "pca parameters: \"pc1 pc2 ...\" [must be defined in sample file]", cxxopts::value<string>());


    auto result = options.parse(argc, argv);

    if (!result.valid_flag) {
        cerr << "Incorrect use of newgwas! Please see Usage." << endl;
        cerr << endl << options.help({""}) << endl;
        exit(0);
    }

    if (result["help"].count() || (result.size() == 0)) {
        cerr << endl << options.help({""}) << endl;
        exit(0);
    }

    if (result["mode"].count()) {
        string input_mode = result["mode"].as<string>();

        if (input_mode == "debug" || input_mode == "d") {
            mode_flag = "d";
            cerr << "enable debug mode" << endl;
        } else if (input_mode == "verbose" || input_mode == "v") {
            mode_flag = "v";
            cerr << "enable verbose mode" << endl;
        } else {
            cerr << "This mode is not exist." << endl;
            cerr << endl << options.help({""}) << endl;
            exit(0);
        }
    }

    if (result["bgen"].count()) {
        ifilename = result["bgen"].as<string>();
    } else {
        cerr << "ERROR: no input bgen file" << endl;
        cerr << endl << options.help({""}) << endl;
        exit(0);
    }

    if (result["sample"].count()) {
        sample_file = result["sample"].as<string>();
    } else {
        cerr << "ERROR: no sample file" << endl;
        cerr << endl << options.help({""}) << endl;
        exit(0);
    }

    if (result["chunk"].count()) {
        chunk = result["chunk"].as<int>();
    } else {
        cerr << "DEFAULT: chunk=100" << endl;
    }

    if (result["range"].count()) {
        range = result["range"].as<int>();
    } else {
        cerr << "DEFAULT: range=100" << endl;
    }

    if (result["threshold"].count()) {
        p_cut = result["threshold"].as<double>();
    } else {
        cerr << "DEFAULT: p_cut=1e-5" << endl;
    }

    if (result["pheno"].count()) {
        pheno = result["pheno"].as<string>();
    } else {
        cerr << "ERROR: no pheno specified" << endl;
        cerr << endl << options.help({""}) << endl;
        exit(0);
    }

    if (result["pca"].count()) {
        pca = result["pca"].as<string>();
        pcas = split(pca, ' ');
        cerr << "PCA: " << endl;
        for (auto &s : pcas)
            cerr << s << " ";
        cerr << endl;
    } else {
        cerr << "WARRING: no pca specified" << endl;
        cerr << endl << options.help({""}) << endl;
        exit(0);
    }

    if (result["output"].count()) {
        ofilename = result["output"].as<string>();
        cerr << "result will be write to: " << ofilename << endl;
    } else {
        ofilename = ifilename + ".result";
        cerr << "DEFAULT: result will be write to: " << ofilename << endl;
    }

    /**
     * End operation parser
     */

    /**
      * init bgen parser
      */
    NewGwas::BgenParser bgenParser(ifilename);
    NewGwas::SampleParser sampleParser(sample_file);
    cerr << "Init sampleParser" << endl;

    if (sampleParser.cols <= 0 || sampleParser.rows <= 0) {
        cerr << endl << "Sample file is empty! Please verify the sample file." << endl;
        exit(0);
    }

    // parse sample header & summary
    cerr << endl;
    cerr << "Reading sample files :" << endl;
    // sampleParser.getSample(), use getSampleHeader() can read less data
    sampleParser.getSampleHeader();
    cerr << "getSampleHeader done" << endl;

    sampleParser.summarise(std::cerr);
    cerr << endl;

    // check pheno & pcas
    vector<int> pheno_idxs, pcas_idxs;
    string pheno_type;
    int pheno_pos;
    cerr << "pheno:" << pheno << endl;
    auto pheno_iter = std::find(std::begin(sampleParser.name), std::end(sampleParser.name), pheno);
    if (pheno_iter == std::end(sampleParser.name)) {
        cerr << "pheno: " << pheno << " is not included in sample file" << endl;
        exit(0);
    }
//    cerr << "before distance :" << pheno_iter << endl;
    pheno_pos = distance(std::begin(sampleParser.name), pheno_iter);
    cerr << "after distance :" << pheno_pos << endl;

    pheno_idxs.emplace_back(pheno_pos);
    cerr << "pheno_idxs size : " << pheno_idxs.size() << endl;
    pheno_type = sampleParser.type[pheno_pos];
    cerr << "pheno type : " << pheno_type << endl;

    // check pcas & get pcas data
    for (auto &s : pcas) {
        cerr << "variants : " << s << endl;
        auto r = std::find(std::begin(sampleParser.name), std::end(sampleParser.name), s);
        if (r == std::end(sampleParser.name)) {
            cerr << "pca: " << s << " is not included in sample file" << endl;
            exit(0);
        }
        pcas_idxs.emplace_back(distance(std::begin(sampleParser.name), r));
    }
    cerr << "sampleParser.rows : " << sampleParser.rows << endl;
    // get sample data
    // Here X2 is consist of pcas data, so X2_size = pcas.size
    int X2_size = pcas.size();
    double *X2 = (double *) _mm_malloc(sizeof(double) * X2_size * sampleParser.rows, 64);
    double *Y = (double *) _mm_malloc(sizeof(double) * sampleParser.rows, 64);
    sampleParser.getColumns(pheno_idxs, Y);
    sampleParser.getColumns(pcas_idxs, X2);

    //bgen summary
    cerr << endl;
    bgenParser.summarise(std::cerr);
    // sampleParse.rows is equal to bgenParser.number_of_samples()
    int number_of_samples = bgenParser.number_of_samples();
    int number_of_variants = bgenParser.number_of_variants();
    cerr << "number_of_samples : " << number_of_samples << endl;
    cerr << "number_of_variants : " << number_of_variants << endl;


    // phenotype summary
    cerr << endl;
    cerr << "Phenotype being used : " << sampleParser.name[pheno_pos] << endl;
    // ... //
    cerr << endl;

    std::vector <NewGwas::Variant> variants;
    NewGwas::Variant variant;
    std::vector <std::vector<double>> probs;
    std::vector<double> gwas_result;

    //DEBUG only
    int count = 0;
    int chunk_start = 0;

    // prepare X buffer
    // size == chunk
    int X_size = X2_size + 1;
    double **Xs = (double **) malloc(sizeof(double *) * chunk);
    int offset = number_of_samples;
    for (int i = 0; i < chunk; ++i) {
        Xs[i] = (double *) malloc(sizeof(double) * X_size * number_of_samples);
//        if (i == 0) {
//            FILE *fp = fopen("/mnt/d/t1.txt", "w");
//            int tot = X_size * number_of_samples;
//            for (int j = 0; j < tot; j++) {
//                if (j % 10000 == 0)printf("%d/%d\n", j, tot);
//                fprintf(fp, "%.5f ", Xs[i][j]);
//            }
//            fprintf(fp, "\n");
//        }
//        cerr << "Xs : " << Xs[i] << endl;
        // leave first number_of_samples size for snps data
        memcpy(Xs[i] + offset, X2, sizeof(double) * X2_size * number_of_samples);
//        cerr << "Xs[i] + offset : " << Xs[i] + offset << endl;
//        cerr << "Xs[i] + 1 : " << Xs[i] + 1 << endl;
//        cerr << "det : " << Xs[i] + offset - Xs[i] << endl;
//
//        cerr << "something bad : " << endl;
//        cerr << "totle size : " << sizeof(double) * X_size * number_of_samples << endl;
//        cerr << "X2 size : " << sizeof(double) * X2_size * number_of_samples << endl;
//        cerr << "offset size : " << offset << endl;
//        cerr << "X2 size + offset size : " << sizeof(double) * X2_size * number_of_samples + offset << endl;
//        cerr << endl;


    }

    std::chrono::duration<double> compute_used;
    // prepare time
    auto time_prepare = chrono::steady_clock::now();
    auto compute_start = chrono::steady_clock::now();

    std::chrono::duration<double> compute_usedp;
    std::chrono::duration<double> compute_usedc;


    int totVariant = number_of_variants;
    printf("totVariant : %d\n", totVariant);

    int preC = totVariant / chunk;
    printf("preC : %d\n", preC);


    int *jbNotReady;
    jbNotReady = (int *) malloc(preC * sizeof(int));
    for (int j = 0; j < preC; j++) {
        jbNotReady[j] = 1;
    }
//
#pragma omp parallel sections default(none) private(i, j, chunk_startt) shared(number_of_samples, preC, number_of_variants, probs, jbNotReady, variants, variant, chunk_start, gwas_result, count, bgenParser, chunk, Xs, Y, X_size, pheno_type, gwas_result)
//#pragma omp parallel sections
    {
        // producer
#pragma omp section
        {
            for (int j = 0; j < preC; j++) {
                for (int i = 0; i < chunk; i++) {
                    bgenParser.read_variant(&(variant.chromosome), &(variant.position), &(variant.rsid),
                                            &(variant.alleles));
                    bgenParser.read_probs(&probs);
                    assert(probs.size() == number_of_samples);
                    NewGwas::probsToSnps(probs, variant.snps, false);
                    variants.push_back(variant);
                    count++;
                }
                printf("job %d has perpared!\n", j);
                jbNotReady[j] = 0;
#pragma omp flush
            }
        }
        // consumer
#pragma omp section
        {
//#pragma omp parallel for num_threads(2)

            for (int j = 0; j < preC / 2; j++) {
#pragma omp flush
                while (jbNotReady[j]) {
#pragma omp flush
                }
                printf("job %d has started!\n", j);
                int start = j * chunk;
                for (int i = 0; i < chunk; ++i) {
                    prepare_data(i, variants, Xs[i], start, number_of_samples);
                    do_calculation(Xs[i], Y, number_of_samples, X_size, pheno_type, 25, gwas_result);
                    free(variants[start + i].snps);
                }
//                process_snps(variants, Xs, Y, chunk_startt,
//                             chunk < number_of_variants - chunk_startt ? chunk : number_of_variants - chunk_startt, \
//            number_of_samples, X_size, pheno_type, gwas_result);
                printf("job %d has done!\n", j);
            }
        }
#pragma omp section
        {
//#pragma omp parallel for num_threads(2)

            for (int j = preC / 2; j < preC; j++) {
#pragma omp flush
                while (jbNotReady[j]) {
#pragma omp flush
                }
                printf("job %d has started!\n", j);
                int start = j * chunk;
                for (int i = 0; i < chunk; ++i) {
                    prepare_data(i, variants, Xs[i], start, number_of_samples);
                    do_calculation(Xs[i], Y, number_of_samples, X_size, pheno_type, 25, gwas_result);
                    free(variants[start + i].snps);
                }
//                process_snps(variants, Xs, Y, chunk_startt,
//                             chunk < number_of_variants - chunk_startt ? chunk : number_of_variants - chunk_startt, \
//            number_of_samples, X_size, pheno_type, gwas_result);
                printf("job %d has done!\n", j);
            }
        }
    }




    auto compute_1 = chrono::steady_clock::now();
    for (int i = 0; i < number_of_variants; i++) {
        bgenParser.read_variant(&(variant.chromosome), &(variant.position), &(variant.rsid), &(variant.alleles));
        bgenParser.read_probs(&probs);
        assert(probs.size() == number_of_samples);
        NewGwas::probsToSnps(probs, variant.snps, false);
        variants.push_back(variant);
        count++;
    }
    auto compute_2 = chrono::steady_clock::now();
    compute_usedc = chrono::duration_cast < chrono::duration < double >> (compute_2 - compute_1);
    printf("Prepare data done!\n");
    auto compute_3 = chrono::steady_clock::now();
#pragma omp parallel sections default(none) private(i,  chunk_startt)
    shared(number_of_samples, preC, number_of_variants, probs, jbNotReady, variants, variant, chunk_start, gwas_result, count, bgenParser, chunk, Xs, Y, X_size, pheno_type, gwas_result)

    for (int ids = 0; ids < preC; ids++) {
        int chunk_startt = ids * chunk;
        process_snps(variants, Xs, Y, chunk_startt,
                     chunk < number_of_variants - chunk_startt ? chunk : number_of_variants - chunk_startt, \
            number_of_samples, X_size, pheno_type, gwas_result);

    }
    auto compute_4 = chrono::steady_clock::now();
    compute_usedp = chrono::duration_cast < chrono::duration < double >> (compute_4 - compute_3);

//读取变异信息，包括变异所在的染色体，变异位置信息，变异位点名称和等位基因

//
//    while (bgenParser.read_variant(&(variant.chromosome), &(variant.position),
//                                   &(variant.rsid), &(variant.alleles))) {
////        cerr << "read a variant done : " << variant.chromosome << " " << variant.position << " " << variant.rsid << " "
////             << variant.alleles.size() << " : ";
////        for (string &info:variant.alleles)
////            cerr << info << " ";
////        cerr << endl;
//        bgenParser.read_probs(&probs);
////        cerr << "read probs done : " << endl;
////        for (int id = 0; id < 10; id++) {
////            for (double &info:probs[id])
////                cerr << info << " ";
////            cerr << endl;
////        }
//
//        assert(probs.size() == number_of_samples);
//        NewGwas::probsToSnps(probs, variant.snps, false);
////        NewGwas::probsToSnps(probs, variant.snps, true);
//        variants.push_back(variant);
//
//        count++;
//
////        if (mode_flag == "d") {
////            // if(count == 20) break;
////
////            cerr << probs.size() << ":" << probs[count].size() << ":" \
//// << probs[count][0] << ":" << probs[count][1] << ":" << probs[count][2] << endl;
////
////            auto tmp = *(variant.snps);
////            for (int i = 0; i < 8; ++i) {
////                // -127(uint8) is equal to 10000000, by xor opreation always get first bit
////                if (tmp & -127) cerr << '1';
////                else cerr << '0';
////                tmp <<= 1;
////            }
////            cerr << endl;
////        }
//
//        if ((count % chunk == 0) || (count == number_of_variants)) {
//
//
//
//            //variants 是读取出来的变异 上面输出了
//            //Xs现在存储了所有样本数据里面对应的协变量数据（一/多 列） 前number_of_samples空着存snp
//            //Y对应样本数据中的 表型数据（一列）
//            //
//            //number_of_samples是样本数据中的行数==bgen数据中的行数
//            //X_size是输入的pca的大小+1
//            //
//            auto compute_1 = chrono::steady_clock::now();
//            process_snps(variants, Xs, Y, chunk_start,
//                         chunk < number_of_variants - chunk_start ? chunk : number_of_variants - chunk_start, \
//            number_of_samples, X_size, pheno_type, gwas_result);
//            //            parallel_process_snps(variants, Xs, Y, chunk_start,
////                                  chunk < number_of_variants - chunk_start ? chunk : number_of_variants - chunk_start, \
//            number_of_samples, X_size, pheno_type, gwas_result);
//            auto compute_2 = chrono::steady_clock::now();
//            compute_usedp += chrono::duration_cast < chrono::duration < double >> (compute_2 - compute_1);
//
//
//            chunk_start += chunk;
//            std::cerr << "count: " << count << std::endl;
//        }
//    }
    auto compute_end = chrono::steady_clock::now();
    compute_used +=
            chrono::duration_cast < chrono::duration < double >> (compute_end
                                                                  - compute_start);

// end time
    auto time_end = chrono::steady_clock::now();

    auto total_used = chrono::duration_cast < chrono::duration < double >> (time_end - time_start);
    auto prepare_used = chrono::duration_cast < chrono::duration < double >> (time_prepare - time_start);

    std::cerr << variants.size() << " SNPs Processed" << std::endl;
//    if (mode_flag == "d") {
//        cerr << "Total time: " << total_used.count() << endl;
//        cerr << "Prepare time: " << prepare_used.count() << endl;
//        cerr << "Compute time: " << compute_used.count() << endl;
//    }
    cerr << "Cost : " << total_used.count() << " s" << endl;
    cerr << "Process data cost : " << prepare_used.count() << " s" << endl;
    cerr << "Cal totle cost : " << compute_used.count() << " s" << endl;
    cerr << "Process data in cal cost : " << compute_usedc.count() << " s" << endl;
    cerr << "Cal cost in true : " << compute_usedp.count() << " s" << endl;
    saveResult(gwas_result, ofilename, number_of_variants);

// result filter, p_cut

// ... //

// free data
    for (int i = 0; i < chunk; ++i)
        free(Xs[i]);
    free(Xs);

    _mm_free(X2);
    _mm_free(Y);

    return 0;
}

// prepare data and computing
bool process_snps(std::vector <NewGwas::Variant> &variants, REAL **Xs, REAL *Y, \
int start, int chunk, int nums, int X_size, std::string Y_type, std::vector<double> &res) {
    //make processing chunk
    // FIXME: parallel
//    cerr << "variants : " << endl;
//    for (auto &it:variants) {
//        cerr << "chromosome : " << it.chromosome << endl;
//        cerr << "position : " << it.position << endl;
//        cerr << "rsid : " << it.rsid << endl;
//        cerr << "alleles : " << endl;
//        for (string &info:it.alleles)
//            cerr << info << " ";
//        cerr << endl;
//    }
//    cerr << "start : " << start << endl;
//    cerr << "chunk : " << chunk << endl;
//    cerr << "nums : " << nums << endl;
//    cerr << "X_size : " << X_size << endl;
//    cerr << "Y_type : " << Y_type << endl;
//    std::chrono::duration<double> compute_used1;
//    std::chrono::duration<double> compute_used2;
//    auto compute_1=chrono::steady_clock::now();
//    auto compute_2=chrono::steady_clock::now();
//#pragma omp parallel for num_threads(2)
    for (int i = 0; i < chunk; ++i) {
//        printf("prepare_data : %d/%d\n", i, chunk);
//        compute_1 = chrono::steady_clock::now();
        prepare_data(i, variants, Xs[i], start, nums);
//        compute_2 = chrono::steady_clock::now();
//        compute_used1 += chrono::duration_cast < chrono::duration < double >> (compute_2 - compute_1);
//        if (i == 0) {
//            FILE *fp = fopen("/mnt/d/t2.txt", "w");
//            int tot = X_size * nums;
//            for (int j = 0; j < tot; j++) {
//                if (j % 10000 == 0)printf("%d/%d\n", j, tot);
//                fprintf(fp, "%.5f ", Xs[i][j]);
//            }
//            fprintf(fp, "\n");
//        }
//        printf("do_calculation : %d/%d\n", i, chunk);
//        compute_1 = chrono::steady_clock::now();
        do_calculation(Xs[i], Y, nums, X_size, Y_type, 25, res);
//        compute_2 = chrono::steady_clock::now();
//        compute_used2 += chrono::duration_cast < chrono::duration < double >> (compute_2 - compute_1);

        free(variants[start + i].snps);
    }
//    cerr << "Calculate 1 cost : " << compute_used1.count() << " s" << endl;
//    cerr << "Calculate 2 cost : " << compute_used2.count() << " s" << endl;

    return true;
}

// prepare data and computing in parallel
bool parallel_process_snps(std::vector <NewGwas::Variant> &variants, REAL **Xs, REAL *Y, \
int start, int chunk, int nums, int X_size, std::string Y_type, std::vector<double> &res) {
    //make processing chunk
    // #pragma omp parallel num_threads(chunk)
#pragma omp parallel for
    for (int i = 0; i < chunk; ++i) {
        prepare_data(i, variants, Xs[i], start, nums);
        do_calculation(Xs[i], Y, nums, X_size, Y_type, 25, res);

        free(variants[start + i].snps);
    }

    return true;
}

// get snps in double and fill Xs buffer
bool prepare_data(int ids, std::vector <NewGwas::Variant> &variants, REAL *buffer, int start, int nums) {
    int offset = start + ids;
//    cerr << "buffer : " << buffer << endl;
    NewGwas::snpsToDouble(variants[offset].snps, buffer, nums);

    // free(variants[offset].snps);

    return true;
}

bool do_calculation(double *X, double *Y, int N, int M, std::string Y_type, int iters, std::vector<double> &res) {
//    TTT += 1;
//    printf("TTT :%d \n", TTT);
//    cerr << "start computer : " << endl;
//    cerr << "N:" << N << endl;
//    cerr << "M:" << M << endl;
//    cerr << "Y_type:" << Y_type << endl;
//    cerr << "iters:" << iters << endl;

    int *stratum, *rank = (int *) malloc(sizeof(int)), *df_resid = (int *) malloc(sizeof(int));
    double *Xb, *fitted, *resid, *weights, *coeff, *std_err, *prior, *scale = (double *) malloc(sizeof(double));

    stratum = (int *) malloc(sizeof(int) * N);
    prior = (double *) malloc(sizeof(double) * N);
//    Xb = (double *) malloc(sizeof(double) * N * N);
//    Xb = (double *) malloc(sizeof(double) * N);
    Xb = (double *) malloc(sizeof(double) * N * (M + 1));
    resid = (double *) malloc(sizeof(double) * N);
    weights = (double *) malloc(sizeof(double) * N);
    fitted = (double *) malloc(sizeof(double) * N);
    coeff = (double *) malloc(sizeof(double) * (M + 1));
    std_err = (double *) malloc(sizeof(double) * (M + 1));

    // glm_fit(3, 3, 100, 11, 1, Y, prior, X, NULL, iters, 0, 0, \
	// 	rank, Xb, fitted, resid, weights, scale, df_resid, coeff, std_err);

    if (Y_type == "P") {
        glm_fit(3, 3, N, M, 0, Y, prior, X, stratum, iters, 0, 0, \
        rank, Xb, fitted, resid, weights, scale, df_resid, coeff, std_err);
    } else {
        glm_fit(1, 1, N, M, 0, Y, prior, X, stratum, iters, 0, 0, \
        rank, Xb, fitted, resid, weights, scale, df_resid, coeff, std_err);
    }
    string ofilename = "res.out";
//    cerr << "df_resid : " << *df_resid << endl;
//    cerr << "scale : " << *scale << endl;
//    cerr << "rank : " << *rank << endl;
//
//    for (int i = 0; i < M; i++)
//        cerr << "coeff : " << coeff[i] << endl;
//    for (int i = 0; i < M; i++)
//        cerr << "std_err : " << std_err[i] << endl;

    free(stratum);
    free(prior);
    free(Xb);
    free(resid);
    free(weights);
    free(coeff);

    return true;
}
